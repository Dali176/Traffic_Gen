# /opt/full_sim.py

import os
import random
import subprocess
import time

MYINTIP = os.environ.get("MYINTIP", "172.16.3.2")
MYPUBIP = os.environ.get("MYPUBIP", "172.16.2.100")

INT_HOSTS = [f"172.16.3.{i}" for i in range(2, 12) if f"172.16.3.{i}" != MYINTIP]
PUB_TARGETS = [f"172.16.2.{i}" for i in range(1, 20)]

USER_AGENTS = ["curl/7.68.0", "Mozilla/5.0", "wget/1.20.3"]

def simulate_ssh():
    target = random.choice(INT_HOSTS)
    subprocess.run([
        "ssh", target,
        "-o", "StrictHostKeyChecking=no",
        "-o", "ConnectTimeout=2",
        "-o", "BatchMode=yes",
        "echo OK"
    ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

def simulate_smb():
    target = random.choice(INT_HOSTS)
    subprocess.run([
        "smbclient", f"//{target}/share", "-U", "user%pass", "-c", "dir"
    ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

def simulate_ping():
    target = random.choice(PUB_TARGETS)
    subprocess.run(["ping", "-c", "1", target], stdout=subprocess.DEVNULL)

def simulate_http():
    target = f"http://{random.choice(PUB_TARGETS)}"
    agent = random.choice(USER_AGENTS)
    subprocess.run(["curl", "-A", agent, "--max-time", "2", target],
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

def loop():
    while True:
        internal_action = random.choice([simulate_ssh, simulate_smb])
        public_action = random.choice([simulate_ping, simulate_http])

        internal_action()
        time.sleep(random.randint(5, 15))
        public_action()
        time.sleep(random.randint(10, 30))

if __name__ == "__main__":
    loop()
