#!/bin/bash

NUM_HOSTS=10
BR0="br0"  # Public network bridge (172.16.2.0/24)
BR1="br1"  # Internal network bridge (172.16.3.0/24)
TRAFFIC_SCRIPT="/opt/full_sim.py"

# Create bridges if not exist
for BR in $BR0 $BR1; do
    ip link show $BR >/dev/null 2>&1 || {
        echo "[*] Creating bridge $BR..."
        ip link add name $BR type bridge
        ip link set $BR up
    }
done

for i in $(seq 1 $NUM_HOSTS); do
    NS="red$i"
    PUB="veth-${NS}-pub"
    INT="veth-${NS}-int"
    PEER_PUB="peer-${NS}-pub"
    PEER_INT="peer-${NS}-int"
    PUB_IP="172.16.2.$((100 + i))"
    INT_IP="172.16.3.$((1 + i))"

    MAC_PUB=$(printf "02:AA:%02x:%02x:%02x:%02x" $((RANDOM%256)) $((RANDOM%256)) $((RANDOM%256)) $((RANDOM%256)))
    MAC_INT=$(printf "02:BB:%02x:%02x:%02x:%02x" $((RANDOM%256)) $((RANDOM%256)) $((RANDOM%256)) $((RANDOM%256)))

    echo "[*] Setting up $NS with Public $PUB_IP and Internal $INT_IP"

    ip netns add $NS

    # Create veth pairs
    ip link add $PUB type veth peer name $PEER_PUB
    ip link add $INT type veth peer name $PEER_INT

    # Move to namespace
    ip link set $PUB netns $NS
    ip link set $INT netns $NS

    # Assign IPs and MACs
    ip netns exec $NS ip addr add $PUB_IP/24 dev $PUB
    ip netns exec $NS ip link set $PUB address $MAC_PUB
    ip netns exec $NS ip link set $PUB up

    ip netns exec $NS ip addr add $INT_IP/24 dev $INT
    ip netns exec $NS ip link set $INT address $MAC_INT
    ip netns exec $NS ip link set $INT up

    ip netns exec $NS ip link set lo up

    # Attach to bridges
    ip link set $PEER_PUB master $BR0
    ip link set $PEER_PUB up

    ip link set $PEER_INT master $BR1
    ip link set $PEER_INT up

    # Start simulation script in background
    ip netns exec $NS env MYINTIP=$INT_IP MYPUBIP=$PUB_IP python3 $TRAFFIC_SCRIPT &
done

echo "[+] All hosts started with public + internal traffic."
