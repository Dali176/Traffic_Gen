#!/bin/bash

echo "[*] Cleaning up Red Cell simulation..."

pkill -f full_sim.py

for i in $(seq 1 10); do
    ip netns del red$i 2>/dev/null
    ip link del peer-red$i-pub 2>/dev/null
    ip link del peer-red$i-int 2>/dev/null
done

ip link del br0 2>/dev/null
ip link del br1 2>/dev/null

echo "[+] Cleanup complete."
